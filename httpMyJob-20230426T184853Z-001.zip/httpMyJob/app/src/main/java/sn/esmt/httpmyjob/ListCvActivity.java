package sn.esmt.httpmyjob;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import sn.esmt.httpmyjob.httpconfig.Api;
import sn.esmt.httpmyjob.httpconfig.OffreEmploi;
import sn.esmt.httpmyjob.tools.OffreEmploiAdapter;

public class ListCvActivity extends AppCompatActivity {

    private ListView list;
    private ArrayList<OffreEmploi> cvs = new ArrayList<OffreEmploi>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_cv);
        list = (ListView) findViewById(R.id.listCv);
        chargerListe();
    }
    public void chargerListe(){

        //Création de l'objet Retrofit pour accéder à l'API
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.4:8081") //URL de base de l'API
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        //Crée une instance de l'interface Api,
        //qui définit les méthodes pour les appels HTTP.
        Api api = retrofit.create(Api.class);

        //creation d'un objet Call pour l'appel à la méthode login() de l'interface Api.
        Call<ArrayList<OffreEmploi>> call = api.all();

        call.enqueue(new Callback<ArrayList<OffreEmploi>>() {
            @Override
            public void onResponse(Call<ArrayList<OffreEmploi>> call, Response<ArrayList<OffreEmploi>> response) {
                if (response.isSuccessful()) {
                    Log.d("Response :", response.body().get(0).getEmail());
                    response.body().stream().forEach(offreEmploi -> cvs.add(offreEmploi));
                    OffreEmploiAdapter adpt = new OffreEmploiAdapter(ListCvActivity.this,cvs);
                    Log.d("Debbugage : " , cvs.get(0).getNom());
                    list.setAdapter(adpt);
                } else {
                    Log.d("error message exception", response.toString());

                }
            }

            @Override
            public void onFailure(Call<ArrayList<OffreEmploi>> call, Throwable t) {
                Log.d("Error : ", t.getMessage());
                //D/Error :: CLEARTEXT communication to 192.168.90.167 not permitted by network security policy
            }

        });
    }
}