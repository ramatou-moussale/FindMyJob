package sn.esmt.httpmyjob.httpconfig;

public class DetailOffreEmploi {
}
